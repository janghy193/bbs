package com.example.demo.dao;

import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.example.demo.vo.UserVO;

@Repository("mysqlDao")
public class UserMysqlDAO implements UserDAO {
	
	@Autowired	// dependency injection
	JdbcTemplate jdbcTemplate;	// new 없이 사용. 보통이면 null pointer exception 발생

	@Override
	public boolean insert(UserVO u) {
		/* UserVO(num,name,phone,email) MySQL user 테이블의 num은 Auto-Increment 설정*/
		String sql = "INSERT INTO user VALUES(NULL,?,?,?)";
		int rows = jdbcTemplate.update(sql, u.getName(), u.getPhone(), u.getEmail());  // update시 적용된 행 수 리턴됨
		return rows>0; // 적용된 행 수가 0이 넘는지를 boolean값으로 리턴
		
		/* 레코드를 저장할 때 자동으로 생성된 필드의 값을 가져오는 방법
		String sql = "INSERT INTO user VALUES(NULL,?,?,?)";
		KeyHolder keyHolder = new GeneratedKeyHolder();
		jdbcTemplate.update(conn->{			// 람다 식. 함수형 클래스를 다룸
			PreparedStatement pstmt = conn.prepareStatement(
				sql, new String[]{"num"});  // key column 의미. 가져와야 할 컬럼명을 지정. 
											// num컬럼에 있는 값을 가져오라는 의미. primary key가 여러 컬럼일 수 있으므로 String 배열형
			pstmt.setString(u.getName());
			pstmt.setString(u.getPhone());
			pstmt.setString(u.getEmail());
			return pstmt;
		},keyHolder);	// 2번째 인자로 준 keyHolder가 update의 첫 번째 인자로 실행되어 얻어진 자동증가필드의 값을 저장받음
		return keyHolder.getKey().intValue();	// KeyHolder에서 입력받은 key값을 추출하여 리턴
		*/
	}

	@Override
	public UserVO select(int num) {	// 1개의 행 값 가져옴, UserVO형으로 반환
		String sql = "SELECT * FROM user WHERE num=?";
		return jdbcTemplate.queryForObject(sql,(rs,i)->		// queryForObject ==> 실행결과를 Object로 받음??
		// sql 실행 후 결과문이 ResultSet형 rs로 넘어옴, i는 행을 지시하는 값. 1행이라 여기서는 필요없으나 규격임
		new UserVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4)) // index값은 컬럼의 번호
		, num);
	}

	@Override
	public boolean update(UserVO u) {
		System.out.println("-------------mysqlDAO-update()-----------");
		
		// 선 가공 (null로 온 값을 기존 값으로 대체해줌)
		UserVO uu = select(u.getNum());
		
		if(u.getName()=="") {
			u.setName(uu.getName());
		}if(u.getPhone()=="") {
			u.setPhone(uu.getPhone());
		}if(u.getEmail()=="") {
			u.setEmail(uu.getEmail());
		}
		
		String sql = "UPDATE user SET name=?, phone=?, email=? WHERE num=?";
		int rows = jdbcTemplate.update(sql, u.getName(),u.getPhone(), u.getEmail(), u.getNum());  // update시 적용된 행 수 리턴됨
		return rows>0; // 적용된 행 수가 0이 넘는지를 boolean값으로 리턴
	}

	@Override
	public boolean delete(int num) {
		System.out.println("-------------mysqlDAO-delete()-----------");
		String sql = "DELETE FROM user WHERE num=?";
		int rows = jdbcTemplate.update(sql,num);
		return rows>0;
	}

	@Override
	public ArrayList<UserVO> getList() {
		System.out.println("-------------mysqlDAO-getList()-----------");
		String sql = "SELECT * FROM user";
		List<UserVO> uList = jdbcTemplate.query(sql, (rs,i)->
		new UserVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4)));
		return new ArrayList<UserVO>(uList);
	}

	@Override
	public UserVO getPicName(int num) {
		return null;
	}

	@Override
	public int insertAndGetId(UserVO u) {
		String sql = "INSERT INTO user VALUES(NULL,?,?,?)";
		KeyHolder keyHolder = new GeneratedKeyHolder();
		jdbcTemplate.update(conn->{			// 람다 식. 함수형 클래스를 다룸
			PreparedStatement pstmt = conn.prepareStatement(
				sql, new String[]{"num"});  // key column 의미. 가져와야 할 컬럼명을 지정. 
											// num컬럼에 있는 값을 가져오라는 의미. primary key가 여러 컬럼일 수 있으므로 String 배열형
			pstmt.setString(1, u.getName());
			pstmt.setString(2 ,u.getPhone());
			pstmt.setString(3, u.getEmail());
			return pstmt;
		},keyHolder);	// 2번째 인자로 준 keyHolder가 update의 첫 번째 인자로 실행되어 얻어진 자동증가필드의 값을 저장받음
		return keyHolder.getKey().intValue();	// KeyHolder에서 입력받은 key값을 추출하여 리턴
	}

	@Override
	public int getCount() {
		String sql = "SELECT COUNT(*) FROM user";
		int cnt = jdbcTemplate.queryForObject(sql, Integer.class);  // Integer로 반환된 뒤 언박싱
		return cnt;
	}

	@Override
	public String getName(int num) {
		String sql = "SELECT name FROM user WHERE num=?";
		String name = jdbcTemplate.queryForObject(sql, String.class);
		return null;
	}

}
