package com.example.demo.dao;

import java.util.ArrayList;

import com.example.demo.vo.UserVO;

public interface UserDAO {

	boolean insert(UserVO u);
	int insertAndGetId(UserVO u);
	UserVO select(int num);
	boolean update(UserVO u);
	boolean delete(int num);
	ArrayList<UserVO> getList();
	public UserVO getPicName(int num);
	public int getCount();
	public String getName(int num);
	
}
