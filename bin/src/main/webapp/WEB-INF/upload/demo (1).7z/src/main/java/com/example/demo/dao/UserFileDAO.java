package com.example.demo.dao;

import java.io.*;
import java.util.ArrayList;
import java.util.function.Consumer;

import org.springframework.stereotype.Repository;

import com.example.demo.vo.UserVO;

@Repository("fileDAO")
public class UserFileDAO implements UserDAO {

	private static final String filepath = "c:/test/user.csv";

	@Override
	public boolean insert(UserVO u) {
		String line = String.format("%d, %s, %s, %s", u.getNum(), u.getName(), u.getPhone(), u.getEmail());
		try {
			PrintWriter pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream(filepath, true), "utf-8"));
			pw.println(line);
			pw.close();
			return true;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	@Override
	public ArrayList<UserVO> getList() {
		try {
				String line = "";
				BufferedReader br = new BufferedReader(new FileReader(filepath));

				ArrayList<UserVO> list = new ArrayList<>();
				while ((line = br.readLine()) != null) {
					String[] info = line.split(",");
					list.add(new UserVO(Integer.parseInt(info[0]),info[1],info[2],info[3]));
				}
				return list;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}
	/*
	@Override
	public ArrayList<UserVO> getList(){ 
	      try {
	         BufferedReader br=new BufferedReader(new FileReader(filepath));
	         String line=null;
	         ArrayList<UserVO> list=new ArrayList<>();
	         while((line=br.readLine())!=null) {
	            String[] info=line.split(",");
	            int num=Integer.parseInt(info[0]);
	            UserVO u=new UserVO();
	            u.setNum(num);
	            u.setName(info[1]);
	            u.setPhone(info[2]);
	            u.setEmail(info[3]);
	            list.add(u);
	         }
	         return list;
	      }catch(Exception e) {
	         e.printStackTrace();
	         return null;
	      }
	   }*/

	@Override
	public boolean update(UserVO u) {

		try {/*
				 * ArrayList<UserVO> list = new ArrayList<>(); BufferedReader br = new
				 * BufferedReader(new FileReader(filepath)); String line = null;
				 * 
				 * while ((line = br.readLine()) != null) { list.add(parseLine(line)); }
				 * 
				 * int num = u.getNum();
				 * 
				 * 
				 * for(int i = 0; i<list.size(); i++) { // 입력받은 객체를 list의 번호를 찾아가 대체
				 * if(list.get(i).getNum() == num) { list.get(i).setNum(u.getNum());
				 * list.get(i).setName(u.getName()); list.get(i).setPhone(u.getPhone());
				 * list.get(i).setEmail(u.getEmail()); } }
				 * 
				 * PrintWriter pw = new PrintWriter(new OutputStreamWriter(new
				 * FileOutputStream(filepath), "utf-8")); for(int i = 0; i<list.size(); i++) {
				 * // 파일 업데이트 line = String.format("%d, %s, %s, %s", u.getNum(), u.getName(),
				 * u.getPhone(), u.getEmail()); pw.println(line); }
				 * 
				 * pw.close();
				 */
			String line = "";
			BufferedReader br = new BufferedReader(new FileReader(filepath));
			ArrayList<String> list = new ArrayList<>();
			while ((line = br.readLine()) != null) {
				String[] info = line.split(",");
				int inNum = Integer.parseInt(info[0]);
				if (u.getNum() == inNum) {
					line = String.format("%d,%s,%s,%s", u.getNum(), u.getName(), u.getPhone(), u.getEmail());
				}
				list.add(line);
			}
			br.close();
			PrintWriter pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream(filepath), "utf-8"));
			// Comsumer 구현 클래스 정의
			// Consumer 익명 클래스 정의

			/*
			 * Consumer cs; // 클래스로 구체화 cs = new ImplConsumer(pw); list.forEach(cs);
			 * 
			 * list.forEach(new Consumer<String>() { // 익명클래스
			 * 
			 * @Override public void accept(String e) { pw.println(e); } });
			 */
			list.forEach(e -> pw.println(e)); // 람다식

			pw.close();
			return true;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean delete(int num) {
		try {
			String line = "";
			BufferedReader br = new BufferedReader(new FileReader(filepath));
			ArrayList<String> list = new ArrayList<>();
			while ((line = br.readLine()) != null) {
				String[] info = line.split(",");
				int inNum = Integer.parseInt(info[0]);
				if (num != inNum) {
					list.add(line);
				}
			}
			br.close();
			PrintWriter pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream(filepath), "utf-8"));
			list.forEach(e -> pw.println(e)); // 람다식

			pw.close();
			return true;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public UserVO select(int num) {
	
		return null;
	}

	@Override
	public UserVO getPicName(int num) {
		try {
			String filename = null;
			UserVO u = new UserVO();
			String line = "";
			BufferedReader br = new BufferedReader(new FileReader(filepath));

			while ((line = br.readLine()) != null) {
				String[] info = line.split(",");
				int nn = Integer.parseInt(info[0]);
				if(nn == num) {
					return new UserVO(nn,info[1],info[2],info[3],info[4]);
				}
			}
			
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public int insertAndGetId(UserVO u) {
		return 0;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getName(int num) {
		// TODO Auto-generated method stub
		return null;
	}
	

}

class ImplConsumer implements Consumer {
	private PrintWriter pw;

	public ImplConsumer(PrintWriter pw) {
		this.pw = pw;
	}

	@Override
	public void accept(Object t) {
		pw.println(t);

	}

}