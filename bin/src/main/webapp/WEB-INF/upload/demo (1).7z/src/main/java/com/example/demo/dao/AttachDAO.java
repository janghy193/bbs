package com.example.demo.dao;

import java.util.ArrayList;

import com.example.demo.vo.AttachVO;

public interface AttachDAO {
	public boolean save(AttachVO a);
	public ArrayList<String> getFileList(int num);
}
