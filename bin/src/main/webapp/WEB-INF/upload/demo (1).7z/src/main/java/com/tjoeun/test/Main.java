package com.tjoeun.test;

import java.util.Optional;

public class Main {
	public static void main(String[] args) {
		/*
		MyInterface mi;
		mi = new ImplMyinterface();
		
		methodA("안녕하세요?",mi);*/
		
		String str = "Smith";
		Optional<String> optStr = Optional.ofNullable(str);
		sample(optStr);
		
		str = null;
		optStr = Optional.ofNullable(str);
		sample(optStr);
	}
	public static void methodA(String msg, MyInterface intf) {
		intf.println(msg);
	}
	
	public static void sample(Optional<String>optStr) {
		String id = optStr.orElse("Guest");
		System.out.println(id+"님 방가~");
	}
}

interface MyInterface{
	void println(String msg);
	/* abstract는 추상적이다 라는 의미를 갖고 있으며
	 * 온전하게 그 기능을 구현하지 않은 인터페이스 메소드 앞에 붙여야 한다
	 */
}

class ImplMyinterface implements MyInterface {

	@Override
	public void println(String msg) {
		System.out.println(msg);		
	}

}