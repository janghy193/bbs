package com.example.demo.dao;

import java.util.ArrayList;

import com.example.demo.vo.GuestBookVO;

public interface GuestBookDAO {
/*방명록 쓰기, 리스트, 상세보기, 수정, 삭제, 첨부파일 다운로드 */
	public int writeGb(GuestBookVO gb);
	public ArrayList<GuestBookVO> getList();
	public GuestBookVO select(int num);
	public boolean update(GuestBookVO gb);
	public boolean delete(int num);
}
