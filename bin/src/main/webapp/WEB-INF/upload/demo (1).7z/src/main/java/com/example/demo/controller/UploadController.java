package com.example.demo.controller;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

@Controller
public class UploadController {
	
	@Autowired
	ResourceLoader resourceLoader;
	
	@GetMapping("upload")
	public String getForm() {
		return "upload_form";
	}
	
	@ResponseBody
	@PostMapping("upload")
	public String upload(@RequestParam("files") MultipartFile[] mfiles,
			MultipartHttpServletRequest request,     // upload폴더의 절대경로 필요하므로 인자로 사용
			@RequestParam("author") String author) {
		
		ServletContext context = request.getServletContext();
		String savePath = context.getRealPath("/WEB-INF/upload");	// upload폴더의 절대 경로를 얻음
		
		
		try {
			for(int i = 0 ; i<mfiles.length ; i++) {
				mfiles[i].transferTo(new File(savePath+"/"+mfiles[i].getOriginalFilename()));	// 디스크에 있었던 파일의 정보를 메모리에 객체화
				/* MultipartFile 주요 메소드
				String cType = mfiles[i].getContentType();
				String pName = mfiles[i].getOriginalFileName();
				Resource res = mfiles[i].getResource;
				long fSize = mfiles[i].getSize();
				boolean empty = mfiles[i].isEmpty();
				*/
				
				
				
			}
			
			String msg = String.format("파일(%d)저장성공(작성자:%s)",mfiles.length, author);
			
			
			return msg;
		}catch(Exception e) {
			e.printStackTrace();
			return "파일 저장 실패:";
		}
	}
	
	@GetMapping("download/{filename}")
	public ResponseEntity<Resource> download(HttpServletRequest request, @PathVariable String filename){
		Resource resource = resourceLoader.getResource("WEB-INF/upload/"+filename);
		System.out.println("파일명:"+resource.getFilename());
		String contentType = null;
		try {
			contentType = request.getServletContext().getMimeType(resource.getFile().getAbsolutePath()); // 절대파일 경로를 정확하게 구하기 위해
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		if(contentType == null) {
			contentType = "application/octet-stream";  // 브라우저가 그 데이터를 해석을 못하게 하여 저장으로 동작하게 함
		}
		
		return ResponseEntity.ok().contentType(MediaType.parseMediaType(contentType))
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\""+resource.getFilename() + "\"")	// 헤더에 들어갈 내용
				.body(resource);	// 바디에 들어갈 내용
	}
}
