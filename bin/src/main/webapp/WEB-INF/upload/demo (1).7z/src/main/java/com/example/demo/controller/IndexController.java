package com.example.demo.controller;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import org.springframework.stereotype.*;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;


import com.example.demo.dao.UserDAO;
import com.example.demo.vo.UserVO;

@Controller
public class IndexController {
	private UserDAO userDao;
	
	@Autowired
	public IndexController(@Qualifier("mysqlDao") UserDAO dao) {	// 부모 interface이기 때문에 구체화 객체를 바꾸어도 괜찮음
		this.userDao = dao;
	}
	
	@GetMapping
	public String hello(Model model) {
		return "form";
	}
	
	//Gugudan
	@GetMapping("/gugu/{dan}")
	public String gg(@PathVariable("dan") int dan, Model model) {
		String msg = "";
		for(int i = 1 ; i < 10 ; i++) {
			msg += dan + " x " + i + " = " + dan*i + "<br>";
		}
		model.addAttribute("data",msg);
		return "gugu";
	}
	
	@GetMapping("/gugu/param")
	public String gugu(@RequestParam("dan") int dan, Model model){
		String msg = "";
		for(int i = 1 ; i < 10 ; i++) {
			msg += dan + " x " + i + " = " + dan*i + "<br>";
		}
		model.addAttribute("data",msg);
		return "gugu";
	}
	
	@ResponseBody
	@PostMapping("ajax_req")
	public String ajaxGugu(@RequestParam("dan") int dan){
		String msg = "";
		for(int i = 1 ; i < 10 ; i++) {
			msg += dan + " x " + i + " = " + dan*i + "<br>";
		}
		return msg;
	}
	
	@GetMapping("ajax_req")
	public String ajax_page() {
		return "ajax_req";
	}
	
	//User
	@ResponseBody
	@PostMapping("user")
	public String user_save(@ModelAttribute UserVO u) {
		
		 
		return userDao.insert(u)+"";
	}
	
	@GetMapping("user")
	public String gotoUser(@ModelAttribute UserVO u) {
		
		return "form";
	}
	
	@ResponseBody
	@PutMapping("user")
	public String user_update(@ModelAttribute UserVO u) {
		
		 
		return userDao.update(u)+"";
	}
	@ResponseBody
	@DeleteMapping("user")
	public String user_delete(@RequestParam("num") int num) {
		return userDao.delete(num)+"";
	}
	
	@GetMapping("user/list")
	public String user_show(Model model) {
		ArrayList<UserVO> list = userDao.getList();
		
		model.addAttribute("list",list);
		return "userlist";
	}

	@ResponseBody
	@PostMapping("user/pic")
	public Map<String,String> user_pict(@RequestParam("num")int num) {
		UserVO u = new UserVO();
		u=userDao.select(num);
		Map<String,String> map = new HashMap<>();
		map.put("num", u.getNum()+"");
		map.put("name", u.getName());
		map.put("phone", u.getPhone());
		map.put("email", u.getEmail());
		map.put("img", u.getNum()+"");
		return map;
	}
}
