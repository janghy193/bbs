package com.example.demo.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.example.demo.dao.GuestBookDAO;
import com.example.demo.vo.AttachVO;
import com.example.demo.vo.GuestBookVO;
import com.example.demo.dao.AttachDAO;

@Controller
public class GuestBookController {
	private GuestBookDAO dao;
	private AttachDAO adao;
	
	@Autowired
	ResourceLoader resourceLoader;
	
	@Autowired
	public GuestBookController(@Qualifier("gbDao") GuestBookDAO dao, @Qualifier("attDao") AttachDAO adao) {
		this.dao = dao;
		this.adao = adao;
	}
	
	@GetMapping("gb/{page}")
	public String showGbPage(Model model,@PathVariable("page")int page) {
		ArrayList<GuestBookVO> list = dao.getList();
		int rows=10;
		int size = list.size();
		Collections.reverse(list);
		
//		ArrayList<GuestBookVO> revList = new ArrayList<>();
//		for(int i = 0; i <list.size() ; i++) {
//			revList.add(list.get(size-i));
//			System.out.println(revList.get(i));
//		}
		
		int pageEnd = list.size()%rows==0 ? list.size()/rows : list.size()/rows+1;
		int listEnd = (rows-1)+(page-1)*rows;
		int listStt = 0+(page-1)*rows;
		
		model.addAttribute("list",list);
		model.addAttribute("pageEnd",pageEnd);
		model.addAttribute("listStt",listStt);
		model.addAttribute("listEnd",Math.min(size,listEnd));
		return "gblist";
	}
	
	@GetMapping("gb/write")
	public String writeGbList() {
		return "gbwrite";
	}
	
	@GetMapping("gb/read/{num}")
	public String gg(@PathVariable("num") int num, Model model) {
		GuestBookVO gb = dao.select(num);
		model.addAttribute("num",gb.getNum());
		model.addAttribute("title",gb.getTitle());
		model.addAttribute("author",gb.getAuthor());
		model.addAttribute("contents",gb.getContents());
		Optional<String> optStr = Optional.ofNullable(gb.getAttach());
		
		String isFileExist = isNull(optStr, "없음");
		
		if(isFileExist=="없음") {
			model.addAttribute("fileNone",isFileExist);
		}
		else {
			ArrayList<String> fileList = adao.getFileList(num);
			model.addAttribute("fileList",fileList);
		}
		
		
		return "gbread";
	}
	
	@ResponseBody
	@PostMapping("gb/del")
	public String del(@RequestParam("num")int num) {
		return dao.delete(num)+"";
	}
	
	@ResponseBody
	@PostMapping("gb/upd")
	public String upd(@RequestParam("num")int num,@RequestParam("title")String title,@RequestParam("contents")String cont) {
		GuestBookVO gb = dao.select(num);
		gb.setTitle(title);
		gb.setContents(cont);
		return dao.update(gb)+"";
	}
	
	@ResponseBody
	@PostMapping("gb/save")
	public String save(@RequestParam("files") MultipartFile[] mfiles,
			MultipartHttpServletRequest request,     // upload폴더의 절대경로 필요하므로 인자로 사용
			@RequestParam("author") String author, @RequestParam("title")String title, @RequestParam("contents")String contents) {
		
		ServletContext context = request.getServletContext();
		String savePath = context.getRealPath("/WEB-INF/upload");	// upload폴더의 절대 경로를 얻음
		
		boolean isFail=false;
		try {
			
			GuestBookVO gb = new GuestBookVO(0,author,"",title,contents,"");
			int getKey = dao.writeGb(gb);
			
			for(int i = 0 ; i<mfiles.length ; i++) {
				/* MultipartFile 주요 메소드
				String cType = mfiles[i].getContentType();
				String pName = mfiles[i].getName();
				Resource res = mfiles[i].getResource;
				long fSize = mfiles[i].getSize();
				boolean empty = mfiles[i].isEmpty();
				 */
				System.out.println(mfiles[i].getContentType()+", "+mfiles[i].getOriginalFilename()+", "+mfiles[i].getResource());
				mfiles[i].transferTo(new File(savePath+"/"+mfiles[i].getOriginalFilename()));	// 디스크에 있었던 파일의 정보를 메모리에 객체화
				
				AttachVO a = new AttachVO(0,getKey,mfiles[i].getOriginalFilename(),mfiles[i].getSize(),mfiles[i].getContentType());
				isFail = adao.save(a);
			}
			return isFail+"";
		}catch(Exception e) {
			e.printStackTrace();
			return isFail+"";
		}
	}
	
	public static String isNull(Optional<String>optStr, String msg) {
		String out = optStr.orElse(msg);
		return out;
	}
}
