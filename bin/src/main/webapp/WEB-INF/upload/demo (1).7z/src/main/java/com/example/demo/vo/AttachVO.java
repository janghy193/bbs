package com.example.demo.vo;

public class AttachVO {
	private int attnum;
	private int num;
	private String filename;
	private long filesize;
	private String contentType;
	
	public AttachVO() {}
	
	public AttachVO(int attnum, int num, String filename, long filesize, String contentType) {
		super();
		this.attnum = attnum;
		this.num = num;
		this.filename = filename;
		this.filesize = filesize;
		this.contentType = contentType;
	}
	public int getAttnum() {
		return attnum;
	}
	public void setAttnum(int attnum) {
		this.attnum = attnum;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public long getFilesize() {
		return filesize;
	}
	public void setFilesize(long filesize) {
		this.filesize = filesize;
	}
	public String getContentType() {
		return contentType;
	}
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
}
