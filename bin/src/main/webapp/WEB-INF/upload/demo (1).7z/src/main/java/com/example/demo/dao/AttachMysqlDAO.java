package com.example.demo.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.demo.vo.AttachVO;
import com.example.demo.vo.GuestBookVO;

@Repository("attDao")
public class AttachMysqlDAO implements AttachDAO {
	@Autowired	// dependency injection
	JdbcTemplate jdbcTemplate;	// new 없이 사용. 보통이면 null pointer exception 발생
	
	@Override
	public boolean save(AttachVO a) {
		String sql = "INSERT INTO attach_tb VALUES(NULL,?,?,?,?)";
		int rows = jdbcTemplate.update(sql, a.getNum(),a.getFilename(),a.getFilesize(),a.getContentType());
		return rows>0;
	}

	@Override
	public ArrayList<String> getFileList(int num) {
		String sql = "SELECT * FROM attach_tb WHERE num="+num;
		List<String> fList = jdbcTemplate.query(sql, (rs,i)->
		(rs.getString(3)));
		return new ArrayList<String>(fList);
	}
}
