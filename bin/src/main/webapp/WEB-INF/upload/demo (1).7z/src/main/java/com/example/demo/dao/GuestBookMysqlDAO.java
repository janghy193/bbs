package com.example.demo.dao;

import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.example.demo.vo.GuestBookVO;
import com.example.demo.vo.UserVO;

@Repository("gbDao")
public class GuestBookMysqlDAO implements GuestBookDAO{

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Override
	public int writeGb(GuestBookVO gb) {	// 글 작성(저장)
		String sql = "INSERT INTO guestbook VALUES(NULL,?,NOW(),?,?,?)";		
		
		KeyHolder keyHolder = new GeneratedKeyHolder();
		jdbcTemplate.update(conn->{			// 람다 식. 함수형 클래스를 다룸
			PreparedStatement pstmt = conn.prepareStatement(sql, new String[]{"num"});  // key column 의미. 가져와야 할 컬럼명을 지정. 
																	// num컬럼에 있는 값을 가져오라는 의미. primary key가 여러 컬럼일 수 있으므로 String 배열형
			pstmt.setString(1,gb.getAuthor());
			pstmt.setString(2,gb.getTitle());
			pstmt.setString(3,gb.getContents());
			pstmt.setString(4,gb.getAttach());
			return pstmt;
		},keyHolder);	// 2번째 인자로 준 keyHolder가 update의 첫 번째 인자로 실행되어 얻어진 자동증가필드의 값을 저장받음
		return keyHolder.getKey().intValue();	// KeyHolder에서 입력받은 key값을 추출하여 리턴
	}

	@Override
	public ArrayList<GuestBookVO> getList() {	// 전체 테이블 불러오기
		String sql = "SELECT * FROM guestbook";
		List<GuestBookVO> gList = jdbcTemplate.query(sql, (rs,i)->
		new GuestBookVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6)));
		return new ArrayList<GuestBookVO>(gList);
	}

	@Override
	public GuestBookVO select(int num) {	// 하나 선택해서 값 가져옴
		String sql = "SELECT * FROM guestbook WHERE num=?";
		return jdbcTemplate.queryForObject(sql,(rs,i)->
		new GuestBookVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6))
		, num);
	}

	@Override
	public boolean update(GuestBookVO gb) {		// 수정기능
		GuestBookVO gb2 = select(gb.getNum());
		
		String sql = "UPDATE guestbook SET author=?, wdate=NOW(), title=?,contents=?, attach=? WHERE num=?";
		int rows = jdbcTemplate.update(sql, gb.getAuthor(),gb.getTitle(), gb.getContents(), gb.getAttach(), gb.getNum());  // gbpdate시 적용된 행 수 리턴됨
		return rows>0;
	}

	@Override
	public boolean delete(int num) {	// 글 삭제
		String sql = "DELETE FROM guestbook WHERE num=?";
		int rows = jdbcTemplate.update(sql,num);
		return rows>0;
	}
}
